The instructions for compiling and running the created systems.

1) Change the directory to the 'src' folder of the project

2) For the compilation and running of a specific system you need to compile and run its plumber.
To do this you need:

a) For System A:
	- type:
		javac systema/Plumber.java
	- type:
		java systema/Plumber

b) For System B:
	- type:
		javac systemb/Plumber.java
	- type:
		java systemb/Plumber

c) For System C:
	- type:
		javac systemc/Plumber.java
	- type:
		java systemc/Plumber

