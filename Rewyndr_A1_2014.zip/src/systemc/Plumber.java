package systemc;

import filters.AltitudeFilter;
import filters.MergeFilter;
import filters.PressureFilter;
import filters.SourceFilter;


public class Plumber {
	public static void main(String argv[]) {
		/****************************************************************************
		 * Here we instantiate four filters.
		 ****************************************************************************/

		SourceFilter sourceFilterA = new SourceFilter("./SubSetA.dat");
		SourceFilter sourceFilterB = new SourceFilter("./SubSetB.dat");
		MergeFilter mergeFilter = new MergeFilter();
		AltitudeFilter altitudeFilter = new AltitudeFilter();
		PressureFilter pressureFilter = new PressureFilter();
        SinkFilter lessThan10k = new SinkFilter("./LessThan10k.dat");
        SinkFilter sinkFilter = new SinkFilter("./OutputC.dat");
        WildPointSinkFilter wildPointPressureFilter = new WildPointSinkFilter("./WildPoints.dat");
        
		/****************************************************************************
		 * Here we connect the filters starting with two sink filters (Filter A,
		 * B) which we connect to merge filter. Then we connect sink filter to
		 * the merge .
		 ****************************************************************************/

		mergeFilter.Connect(sourceFilterA, 0, 0);
		mergeFilter.Connect(sourceFilterB, 1, 0);
		altitudeFilter.Connect(mergeFilter);
		pressureFilter.Connect(altitudeFilter,0);
        lessThan10k.Connect(altitudeFilter,1);
        sinkFilter.Connect(pressureFilter,0);
		wildPointPressureFilter.Connect(pressureFilter,1);
        /****************************************************************************
		 * Here we start the filters up. All-in-all,... its really kind of
		 * boring.
		 ****************************************************************************/

		sourceFilterA.start();
		sourceFilterB.start();
		mergeFilter.start();
		altitudeFilter.start();
		lessThan10k.start();
		pressureFilter.start();
		sinkFilter.start();
		wildPointPressureFilter.start();

		// NormalSinkFilter sinkFilterA = new
		// NormalSinkFilter("./SubSetAReadable.dat");
		// NormalSinkFilter sinkFilterB = new
		// NormalSinkFilter("./SubSetBReadable.dat");
		// sinkFilterA.Connect(sourceFilterA);
		// sinkFilterB.Connect(sourceFilterB);
		// sinkFilterA.start();
		// sinkFilterB.start();

	} // main
}
