package systema;

import filters.FeetToMeters;
import filters.PressureFilter;
import filters.SourceFilter;
import filters.TemperatureFilter;

public class Plumber {
	   public static void main( String argv[])
	   {
			/****************************************************************************
			* Here we instantiate three filters.
			****************************************************************************/

			SourceFilter sourceFilter = new SourceFilter("./FlightData.dat");
			FeetToMeters altitudeFilter = new FeetToMeters();
			TemperatureFilter temperatureFilter = new TemperatureFilter();
			SinkFilter sinkFilter = new SinkFilter("./OutputA.dat");
			
			/****************************************************************************
			* Here we connect the filters starting with the sink filter (Filter 1) which
			* we connect to Filter2 the middle filter. Then we connect Filter2 to the
			* source filter (Filter3).
			****************************************************************************/

			altitudeFilter.Connect(sourceFilter); 
			temperatureFilter.Connect(altitudeFilter);
			sinkFilter.Connect(temperatureFilter);
			

			/****************************************************************************
			* Here we start the filters up. All-in-all,... its really kind of boring.
			****************************************************************************/

			sourceFilter.start();
			altitudeFilter.start();
			temperatureFilter.start();
			sinkFilter.start();

	   } // main
}