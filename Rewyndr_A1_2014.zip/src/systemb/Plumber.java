package systemb;

import filters.*;

public class Plumber {
	   public static void main( String argv[])
	   {
			/****************************************************************************
			* Here we instantiate three filters.
			****************************************************************************/

			SourceFilter sourceFilter = new SourceFilter("./FlightData.dat");
			FeetToMeters altitudeFilter = new FeetToMeters();
			TemperatureFilter temperatureFilter = new TemperatureFilter();
			PressureFilter pressureFilter = new PressureFilter();
			SinkFilter normalSinkFilter = new SinkFilter("./OutputB.dat");
			WildPointSinkFilter wildPointSinkFilter = new WildPointSinkFilter("./WildPoints.dat");
			
			SinkFilter wpFilter = new SinkFilter("./OutputB.dat");
			
			/****************************************************************************
			* Here we connect the filters starting with the sink filter (Filter 1) which
			* we connect to Filter2 the middle filter. Then we connect Filter2 to the
			* source filter (Filter3).
			****************************************************************************/

			altitudeFilter.Connect(sourceFilter); 
			temperatureFilter.Connect(altitudeFilter);
			pressureFilter.Connect(temperatureFilter);
			normalSinkFilter.Connect(pressureFilter, 0);
			wildPointSinkFilter.Connect(pressureFilter, 1);
			

			/****************************************************************************
			* Here we start the filters up. All-in-all,... its really kind of boring.
			****************************************************************************/

			sourceFilter.start();
			altitudeFilter.start();
			temperatureFilter.start();
			pressureFilter.start();
			normalSinkFilter.start();
			wildPointSinkFilter.start();

	   } // main
}
