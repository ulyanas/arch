package filters;

import java.util.ArrayList;

import framework.FilterFramework;
import framework.Record;


public class AltitudeFilter extends FilterFramework{
	
	// This framework has 2 input ports
	public AltitudeFilter(){
		super(2);
	}
	
	public void run(){
		int bytesread = 0;
		Record lastValidRecord = null;
		ArrayList<Record> wildRecordList = new ArrayList<Record>();
		while(true){
			try
			{
			Record record = new Record();
			byte[] buffer = new byte[record.getRecordLength()];
			for(int i=0; i<=buffer.length-1; i++){
				buffer[i] = ReadFilterInputPort();
				bytesread++;
			}
			record.setBuffer(buffer);
			
			if( record.getAltitude() < 0.0 || (lastValidRecord != null && Math.abs(record.getAltitude() - lastValidRecord.getAltitude()) > 10000 )){
				wildRecordList.add(record);
				byte[] bytes = record.generateByteSequence();
				for(int i=0; i<=bytes.length-1; i++) WriteFilterOutputPort(bytes[i], 1); // write to wild point sink
			}
			// Normal Point
			else{
				// revise wild point using extrapolation
			    if(wildRecordList.size() > 0) reviseWildPointList(wildRecordList, lastValidRecord, record);
				// set not wild point 
				record.setExtra(0);
				byte[] bytes = record.generateByteSequence();
				for(int i=0; i<=bytes.length-1; i++) WriteFilterOutputPort(bytes[i], 0); // output the normal altitude data
				// clear wildRecordList and set lastValidRecord
				
				lastValidRecord = record;
				wildRecordList.clear();
			 }
			}
			catch (EndOfStreamException e)
			{
				
				if(wildRecordList.size() > 0) reviseWildPointList(wildRecordList, lastValidRecord, null);
				ClosePorts();
				System.out.print( "\n" + this.getName() + "::Filter Exiting; bytes read: " + bytesread );
				break;
			}
		}
	}
	
	private void reviseWildPointList(ArrayList<Record> wildRecordList, Record lastValidRecord, Record nextValidRecord){
		double lastValidAltitude = lastValidRecord == null ? 0 : lastValidRecord.getAltitude();
		double nextValidAltitude = nextValidRecord == null ? 0 : nextValidRecord.getAltitude();
		double validAltitude = (lastValidAltitude + nextValidAltitude)/2;
		for(Record wildRecord : wildRecordList){
			wildRecord.setAltitude(validAltitude);
			wildRecord.setExtra(1); // set wild point
			byte[] bytes = wildRecord.generateByteSequence();
			for(int i=0; i<=bytes.length-1; i++) WriteFilterOutputPort(bytes[i], 0);// write to normal point sink
		}		
	}
}